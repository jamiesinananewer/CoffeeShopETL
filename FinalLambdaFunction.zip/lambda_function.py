import csv
import boto3
import psycopg2 as psy
import logging
from io import StringIO
import json

# Set up logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Define S3 bucket
bucket_name = 'livin-bucket'

# Function to extract data from CSV content
def extract_data(csv_content):
    try:
        
        csv_list = []  # Initialize an empty list to store rows
        
        contents = csv.reader(csv_content)  # Read the CSV content
        
        for item in contents:
            csv_list.append(item)  # Append each row to csv_list
        
        keys = ['date_time', 'location', 'customer_name', 'order_list', 'order_total', 'payment_method', 'card_number']
        
        list_of_dicts = [dict(zip(keys, row)) for row in csv_list]  # Convert each row to a dictionary
        
        return list_of_dicts
    
    except Exception as e:
        logger.error(f"Error extracting data: {str(e)}")  # Log any extraction errors
        raise e

# Function to transform extracted data
def transform_data(list_of_dicts, connection):          #list_of_dicts = csv raw data
    
    cursor = connection.cursor()  # Get a cursor for the database connection
    
    # Retrieve existing items from the database
    cursor.execute('SELECT * FROM items')
    
    item_db_rows = cursor.fetchall()
    
    item_db_cols = [desc[0] for desc in cursor.description]  # Get column names

    db_items = []
    
    for row in item_db_rows:
        row_dict = dict(zip(item_db_cols, row))  # Convert each row to a dictionary
        db_items.append(row_dict)
    
    db_items_only = [db_item['item_name'] for db_item in db_items]  # List of item names in the database
    
    try:
        # Remove sensitive information from each row
        for row in list_of_dicts:
            del row['card_number']
            del row['customer_name']
        
        products = []  # List to store unique products
        new_items = []  # List to store new items
        
        for row in list_of_dicts:
            
            order_list = row['order_list']
            
            items = [item.strip() for item in order_list.split(',')]  # Split order_list into individual items
            
            for item in items:
                
                item_name, item_price = item.rsplit(' - ', 1)  # Split item name and price
                
                item_name = item_name.strip()
                
                item_price = float(item_price.strip())
                
                new_item = {'item_name': item_name, 'item_price': item_price}
                
                if new_item not in products:
                    products.append(new_item)  # Add new unique item to products
             
            # Check if the product is already in the database
        for product in products:
            
            prod_name = product['item_name']
                
            if prod_name not in db_items_only:
                
                new_items.append(product)  # Add new product to new_items
                
                db_items.append(product)  # Add product to db_items
                
                db_items[-1]['item_id'] = len(db_items)  # Assign a new item ID
                
        
        # Link order items to their IDs
        for order in list_of_dicts:
            order_id_list = []
            
            for item in db_items:
                price_len = len(str(item['item_price']))
                
                if price_len == 3:                                                  #Create reference strings to compare against
                    ref_string = f"{item['item_name']} - {item['item_price']}0"
                
                elif price_len == 4:
                    ref_string = f"{item['item_name']} - {item['item_price']}"
                
                else:
                    logger.error("ERROR IN price_len")
                
                order_list = order['order_list']
                
                if ref_string in order_list.split(', '):                            #if reference string is in order_list, append item id to order
                    order_id_list.append(item['item_id'])
                
                order['item_ids'] = order_id_list
            
            del order['order_list']  # Remove order_list after linking items to IDs
        
        
        return list_of_dicts, new_items
    
    except Exception as e:
        logger.error(f"Error transforming data: {str(e)}")  # Log any transformation errors
        raise e

# Function to create junction table data
def create_junction_info(orders, recent_order_length, connection):
        
    cursor = connection.cursor()  # Get a cursor for the database connection
    
    
    # Retrieve recent orders from the database
    try:
        cursor.execute('SELECT * FROM orders ORDER BY order_id DESC')
        
        order_db_rows = cursor.fetchmany(recent_order_length)  # Fetch recent orders
        
        # Get column names
        order_db_cols = [desc[0] for desc in cursor.description]  
        
        db_orders = []                                
        
        for row in order_db_rows:
            row_dict = dict(zip(order_db_cols, row))  # Convert each row to a dictionary
            db_orders.append(row_dict)

        
        # Match orders with their items
        
        orders.reverse() #Reverse orders list for parity with db_orders
        
        for j, db_order in enumerate(db_orders):            #Assign item ids from orders to db_orders that correspond with order_id in db_orders

            db_orders[j]['item_ids'] = orders[j]['item_ids']
        
        
        # Create junction table entries
        junction_data = []
        
        for order in db_orders:
            ord_id = order['order_id']
            
            item_order_ids = order['item_ids']
            
            for item_num in item_order_ids:
                junction_data.append((ord_id, item_num))  # Create junction entries
                
        
        return junction_data
    
    except Exception as e:
        logger.error(f"Error in create_junction: {str(e)}")
        raise e

# Main Lambda handler function
def lambda_handler(event, context):
    try:
        connection = psy.connect(
            dbname='livin_la_vida_mocha_cafe_db',
            user='livin_la_vida_mocha_user',
            password='NVvRTLWrWtan7',
            host='redshiftcluster-2mdz2z5k6u5l.cevjfhhfzr6y.eu-west-1.redshift.amazonaws.com',
            port=5439
            )
            
        cursor = connection.cursor() # Get a cursor for the database connection
        

        # SQL statements to create tables if they do not exist
        
        create_orders = '''
        CREATE TABLE IF NOT EXISTS orders (
            order_id INTEGER IDENTITY(1,1) PRIMARY KEY,
            order_location VARCHAR(255) NOT NULL,
            order_total FLOAT NOT NULL,
            order_payment_method VARCHAR(255) NOT NULL,
            order_date_time VARCHAR(255) NOT NULL
        )
        '''
        
        create_items = '''
        CREATE TABLE IF NOT EXISTS items (
            item_id INTEGER IDENTITY(1,1) PRIMARY KEY,
            item_name VARCHAR(255) NOT NULL,
            item_price FLOAT NOT NULL
        )
        '''
        
        create_junction = '''
        CREATE TABLE IF NOT EXISTS order_item_junction (
            order_id INT,
            item_id INT,
            PRIMARY KEY (order_id, item_id)
        )
        '''
        cursor.execute(create_orders)
        cursor.execute(create_items)
        cursor.execute(create_junction)
        
        connection.commit()  # Commit the table creation
        
        
        # Iterate over each SQS message
        for record in event['Records']:
            
            # Extract the S3 event notification from the SQS message
            sqs_body = json.loads(record['body'])
            logger.info(f"SQS body: {sqs_body}")
            
            # Handling different SQS message structures
            if 'Message' in sqs_body:
                s3_event = json.loads(sqs_body['Message'])['Records'][0]['s3']
            
            elif 'Records' in sqs_body:
                s3_event = sqs_body['Records'][0]['s3']
            
            else:
                logger.error("Unexpected SQS message structure")
                raise KeyError("Unexpected SQS message structure")
                

            filename = s3_event['object']['key']
            
            logger.info(f"FILE NAME: {filename} .-->>> LINE 190")  # PUTS THE FILE NAME IN THE LOGS SO WE CAN CHECK IT IS WORKING CORRECTLY
            
            s3_client = boto3.client('s3')
            sqs_client = boto3.client('sqs')
            response = s3_client.get_object(Bucket=bucket_name, Key=filename) # Gets the CSV file from the s3 bucket based on the filename provided by the SQS message
            
            logger.info(f"RESPONSE: {response} .-->>> LINE 195")  # Log the S3 response
            
            csv_content = response['Body'].read().decode('utf-8').splitlines()
            
            
            raw_data = extract_data(csv_content)  # Extract data from the CSV content
            
            
            orders, new_items = transform_data(raw_data, connection)  # Transform the raw data
            
            # SQL statement to insert data into the orders table
            
            order_fill = '''
            INSERT INTO orders (order_location, order_total, order_payment_method, order_date_time)
            VALUES (%s, %s, %s, %s)
            '''
            
            # Insert each order into the orders table
            for order in orders:
                order_data = (order['location'], order['order_total'], order['payment_method'], order['date_time'])
                cursor.execute(order_fill, order_data)

            # SQL statement to insert data into the items table
            
            item_fill = '''
            INSERT INTO items (item_name, item_price)
            VALUES (%s, %s)
            '''
            
            for item in new_items:
                item_data = (item['item_name'], item['item_price'])
                cursor.execute(item_fill, item_data)
            
            connection.commit() #Commit the orders and items entries
            
            recent_order_length = len(orders)  # Get the number of recent orders
            
            
            junction_data = create_junction_info(orders, recent_order_length, connection)  # Create junction data
            
            # SQL statement to insert data into the order_item_junction table
            junction_fill = '''
            INSERT INTO order_item_junction (order_id, item_id)
            VALUES (%s, %s)
            '''
            for junc in junction_data:
                cursor.execute(junction_fill, junc)
                
            connection.commit() #Commit the junction entries
            
            receipt_handle = record['receiptHandle']            # Delete SQS message once used
            sqs_client.delete_message(
                QueueUrl = 'https://sqs.eu-west-1.amazonaws.com/339713081862/Livin_Q',
                ReceiptHandle = receipt_handle
                )

        cursor.close()  # Close the cursor
        connection.close()  # Close the database connection
        
        logger.info("Data inserted successfully into Redshift")  # Log successful data insertion

        return {
            'statusCode': 200,
            'body': {
                'orders': orders,
                'products': new_items,
                'junction_data': junction_data
            }
        }
    except Exception as e:
        logger.error(f"Error in lambda_handler: {str(e)}")  # Log any errors
        raise e
